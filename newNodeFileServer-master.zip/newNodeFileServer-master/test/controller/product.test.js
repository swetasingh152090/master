const request = require('supertest')
const app = require('../../server')
const service = require("../../service/service");
const Response = require('../../models/Response.js')
jest.mock('../../service/service');

describe('Post Endpoints', () => {
    beforeEach(() => {
        // Clear all instances and calls to constructor and all methods:
        // service.mockClear();
    });
    it('should create a new post', async () => {
        let expectedResult = new Response(
            200,
            "Success",
            "Product added successfully",
            [{
                "productId": 10,
                "productName": "tv",
                "productCode": "12",
                "releaseDate": "09-08-1997",
                "description": "bike",
                "price": 32.99,
                "starRating": 1,
                "imageUrl": "wlygfkuygsvgdskgvskd"
            }]
        )
        service.addProductData.mockReturnValue(expectedResult);
        const res = await request(app)
            .post('/api/products/addProduct')
            .send({

                "productId": 10,
                "productName": "tv",
                "productCode": "12",
                "releaseDate": "09-08-1997",
                "description": "bike",
                "price": 32.99,
                "starRating": 1,
                "imageUrl": "wlygfkuygsvgdskgvskd"

            })
        expect(res.statusCode).toEqual(200)
        expect(res).toEqual(expectedResult)
    })
})


//getAllProduct
describe('GET Endpoints', () => {
    beforeEach(() => {
        // Clear all instances and calls to constructor and all methods:
        // service.mockClear();
    });
    it('should get all the product data', async () => {
        let expectedResult = new Response(
            200,
            "Success",
            "Fectched  productsuccessfully",
            [{
                "productId": 107,
                "productName": "tv",
                "productCode": "12",
                "releaseDate": "09-08-1997",
                "description": "bike",
                "price": 32.99,
                "starRating": 1,
                "imageUrl": "wlygfkuygsvgdskgvskd"
            },
            {
                "productId": 108,
                "productName": "tv",
                "productCode": "12",
                "releaseDate": "09-08-1997",
                "description": "bike",
                "price": 32.99,
                "starRating": 1,
                "imageUrl": "wlygfkuygsvgdskgvskd"
            }]
        )
        service.getAllProducts.mockReturnValue(expectedResult);
        const res = await request(app)
            .get('/api/products/getAllProducts')
        expect(res.statusCode).toEqual(200)
        expect(res).toEqual(expectedResult)
    })
})


//getProductById
describe('GET Endpoints', () => {
    beforeEach(() => {
        // Clear all instances and calls to constructor and all methods:
        // service.mockClear();
    });
    it('should fetch product by Id', async () => {
        let expectedResult = new Response(
            200,
            "Success",
            "Here are the product you requested for",
            [{
                "productId": 107,
                "productName": "tv",
                "productCode": "12",
                "releaseDate": "09-08-1997",
                "description": "bike",
                "price": 32.99,
                "starRating": 1,
                "imageUrl": "wlygfkuygsvgdskgvskd"
            }]
        )
        service.getProductByID.mockReturnValue(expectedResult);
        const productId = 107;
        const res = await request(app).get(`/api/products/${productId}`);
        expect(res.statusCode).toEqual(200)
        expect(res).toEqual(expectedResult)
    })
})

//update product data
describe('UPDATE Endpoints', () => {
    beforeEach(() => {
        // Clear all instances and calls to constructor and all methods:
        // service.mockClear();
    });
    it('should update the product data', async () => {
        let expectedResult = new Response(
            200,
            "Success",
            "Product updated  successfully",
            [{
                "productId": 107,
                "productName": "watch",
                "productCode": "12",
                "releaseDate": "09-08-1997",
                "description": "tv",
                "price": 102.99,
                "starRating": 5,
                "imageUrl": "wlygfkuygsvgdskgvskd"
            }]
        )
        service.updateProductData.mockReturnValue(expectedResult);
        const res = await request(app)
            .put('/api/products/upadteProduct')
        expect(res.statusCode).toEqual(200)
        expect(res).toEqual(expectedResult)
    })
})

//delete product data
describe('DELETE  Endpoints', () => {
    beforeEach(() => {
        // Clear all instances and calls to constructor and all methods:
        // service.mockClear();
    });
    it('should be able to delete the product data', async () => {
        let expectedResult = new Response(
            200,
            "Success",
            "Product is deleted",
            [{
                "productId": 107,
                "productName": "watch",
                "productCode": "12",
                "releaseDate": "09-08-1997",
                "description": "tv",
                "price": 102.99,
                "starRating": 5,
                "imageUrl": "wlygfkuygsvgdskgvskd"
            }]
        )
        service.deleteProductById.mockReturnValue(expectedResult);
        const productId = 107;
        const res = await request(app).delete(`/api/products/${productId}`);
        expect(res.statusCode).toEqual(200)
        expect(res).toEqual(expectedResult)
    })
})