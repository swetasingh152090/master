// const request = require('supertest')
// const app = require('../../server')
// describe('Post Endpoints', () => {
//   it('should create a new post', async () => {
//     const res = await request(app)
//       .post('/api/products/addProduct')
//       .send({
//         "productId": 107,
//         "productName": "tv",
//         "productCode": "12",
//         "releaseDate": "09-08-1997",
//         "description": "bike",
//         "price": 32.99,
//         "starRating": 1,
//         "imageUrl": "wlygfkuygsvgdskgvskd"
//       })
//     expect(res.statusCode).toEqual(200)
//     expect(res.body).toHaveProperty('post')
//   })
// })

// //getAllProduct
// describe('GET Endpoints', () => {
//   it('should get all the product details', async () => {
//     const res = await request(app)
//       .get('/api/products/getAllProducts')
//       .send({
//         "productId": 107,
//         "productName": "tv",
//         "productCode": "12",
//         "releaseDate": "09-08-1997",
//         "description": "bike",
//         "price": 32.99,
//         "starRating": 1,
//         "imageUrl": "wlygfkuygsvgdskgvskd"
//       })
//     expect(res.statusCode).toEqual(200)
//     expect(res.body).toHaveProperty('get')
//   })
// })



const request = require('supertest')
const app = require('../../server')
const Dao = require('../../data/dao')

// var dao
beforeEach(function () {
  // dao = new Dao();
});
jest.mock('../../data/dao');
describe('Post Endpoints', () => {
  it('should create a new post', async () => {
    const res = await request(app)
      .post('/api/products/addProduct')
      .send({
        "productId": 108,
        "productName": "tv",
        "productCode": "12",
        "releaseDate": "09-08-1997",
        "description": "bike",
        "price": 32.99,
        "starRating": 1,
        "imageUrl": "wlygfkuygsvgdskgvskd"
      })
    expect(res.statusCode).toEqual(200)
    expect(res.body);
  })
})

//get all product
describe('GET Endpoints', () => {
  it('should all product data', async () => {
    const res = await request(app)
      .get('/api/products/getAllProducts')

    expect(res.statusCode).toEqual(200)
    expect(res.body);
    expect(res.body.posts);
  })

})

//getProductBYId
// it('should fetch a single post', async () => {
//   const postId = 1;
//   const res = await request(app).get(`/api/posts/${postId}`);
//   expect(res.statusCode).toEqual(200);
//   expect(res.body).toHaveProperty('post');
// });
describe('GET Endpoints', () => {
  it('should fetch a single product data ', async () => {

    const productId = 107;
    const res = await request(app).get(`/api/products/${productId}`);
    expect(res.statusCode).toEqual(200);
    expect(res.body);
  });
})

//update a product
describe('UPDATE Endpoints', () => {
  it('should update the  product data ', async () => {
    const res = await request(app)
      .put('/api/products/updateProduct')
      .send({
        "productId": 107,
        "productName": "Bike",
        "productCode": "13",
        "releaseDate": "09-08-1997",
        "description": "watch",
        "price": 32.99,
        "starRating": 1,
        "imageUrl": "wlygfkuygsvgdskgvskd"
      });

    expect(res.statusCode).toEqual(200);
    expect(res.body);
    expect(res.body.post);
  })

});
// it('should return status code 500 if db constraint is violated', async () => {
//   const res = await request(app)
//     .post('/api/products/updateProduct')
//     .send({
//       "statusCode": 500,
//       "status": "Failure",
//       "message": "Internal server error",
//       "data": null
//     });
//   expect(res.statusCode).toEqual(500);
//   expect(res.body).toHaveProperty('error');
// });
// it('should respond with status code 400 if resource is not found', async () => {

//   const res = await (await request(app).put(`/api/products/updateProduct`)).send({
//     "statusCode": 400,
//     "status": "Failure",
//     "message": "Resource not found",
//     "data": null
//   });
//   expect(res.statusCode).toEqual(400);
// });
// const res = await request(app).get(`/api/products/${productId}`);
// expect(res.statusCode).toEqual(200);
// expect(res.body);


// it('should update a post', async () => {
//   const res = await request(app)
//     .put('/api/posts/1')
//     .send({
//       userId: 1,
//       title: 'updated title',
//       content: 'Lorem ipsum',
//     });

//   expect(res.statusCode).toEqual(200);
//   expect(res.body).toHaveProperty('post');
//   expect(res.body.post).toHaveProperty('title', 'updated title');
// });

//delete product
// it('should delete a post', async () => {
//   const res = await request(app).delete('/api/posts/1');
//   expect(res.statusCode).toEqual(204);
// });
describe('GET Endpoints', () => {
  it('should delete a post', async () => {
    const productId = 107;
    const res = await request(app).delete(`/api/products/${productId}`);
    expect(res.statusCode).toEqual(200);
  });

})



