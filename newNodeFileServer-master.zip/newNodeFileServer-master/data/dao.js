const errors = require("../errors/errors");
var fs = require('fs');
const { request } = require("http");
//variable 
let dataPath = "./data/productData.json";
const FileReadingError = errors.FileReadingError;
const ProductAlreadyExistsError = errors.ProductAlreadyExistsError;;
const ProductDoNotExists= errors.ProductDoNotExists;

class Dao {
    //refactor with helper method
    readFile = (callback, returnJson = false, filePath = dataPath, encoding = "utf8") => {
        fs.readFile(filePath, encoding, (err, data) => {
            // console.log("disha jha");
            if (err) {
                throw err;
            }
            callback(returnJson ? JSON.parse(data) : data);
        });
    };
    writeFile = (
        fileData,
        callback,
        filePath = dataPath,
        encoding = "utf8"
    ) => {
        fs.writeFile(filePath, fileData, encoding, (err) => {
            if (err) {
                throw err;
            }
            callback();
        });
    };


    //getall product
    async getAllProducts() {
        try {
            let reqData = fs.readFileSync(dataPath);
            let data = JSON.parse(reqData);
            return data;
        } catch (error) {
            if (error.message === "Unexpected end of Json input") {
                throw new ProductDoNotExists("the file is empty");
            }
            else {
                throw new FileReadingError("Error reading file");
            }
        }
    }

    //get by productId
    async getProductByID(productId) {
        let reqData = fs.readFileSync(dataPath, "utf8");
        console.log("sweta")
        let data = JSON.parse(reqData);
        console.log("deepa");
        let responseData = {};
        let flag;
        for (const element of data) {
            if (productId == element.productId) {
                flag = true;
                console.log("here it is", element);
                responseData = element;
            }
        }
        if (flag) {
            return responseData;
        }
        else {
            throw new ProductDoNotExists("No such product exists");
        }
    }

    //create product
    async addProductData(requestBody) {
        let flag = false;
        let allData;
        let newAddedData = [];
        allData = fs.readFileSync(dataPath, "utf8", (err, data) => {
            if (err) {
                throw err;
            }
        });

        let parsedData = JSON.parse(allData);
        parsedData.map(eachRecord => {
            if (eachRecord.productId === requestBody.productId) {
                flag = true;
            }
        });


        if (!flag) {
            parsedData.push(requestBody);
            this.writeFile(JSON.stringify(parsedData), (fileData) => {
            });

            newAddedData.push(parsedData[parsedData.length - 1])
            return newAddedData;
        }

        if (flag) {
            throw new ProductAlreadyExistsError("Product already exists");
        }
    }


    //update product
    async updateProductData(updateBody) {
        let productId = "";
        let flag = "";
        let reqData;
        let updatedData = [];
        reqData = fs.readFileSync(dataPath, "utf8", (err, data) => {
            if (err) {
                throw err;
            }

        });
        let parsedData = JSON.parse(reqData);
        parsedData.map(eachRecord => {
            if (eachRecord.productId === updateBody.productId) {
                flag = "inserted";
                productId = eachRecord.productId;
                eachRecord.productName = updateBody.productName;
                eachRecord.productCode = updateBody.productCode;
                eachRecord.releaseDate = updateBody.releaseDate;
                eachRecord.description = updateBody.description;
                eachRecord.price = updateBody.price;
                eachRecord.starRating = updateBody.starRating;
                eachRecord.imageUrl = updateBody.imageUrl;

            }
        });

        if (flag === "inserted") {
            this.writeFile(JSON.stringify(parsedData), (fileData) => {
            });

            updatedData.push(parsedData[parsedData.length - 1])
            return updatedData;
        } else {
            throw new ProductDoNotExists("given id do not exists");
        }
    }

    //delete data
    async deleteProductById(productId) {
        let flag;
        let reqData;
        reqData = fs.readFileSync(dataPath, "utf8", (err, data) => {
            if (err) {
                throw err;
            }
        });
        let parsedData = JSON.parse(reqData);
        let responseData = {};
        parsedData.map((eachRecord, index) => {
            if (eachRecord.productId === productId) {
                flag = true;
                responseData = eachRecord;
                parsedData.splice(index, 1);
            }
        });
        if (flag) {
            this.writeFile(JSON.stringify(parsedData), (fileData) => {
            });
            return responseData;
        }
        else {
            throw new ProductDoNotExists("Sorry! This product id do not exists");
        }

    }
}
module.exports = new Dao();