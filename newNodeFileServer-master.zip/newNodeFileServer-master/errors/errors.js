class FileReadingError extends Error {
    constructor(message) {
        super(message);
    }
}

class ProductDoNotExists extends Error {
    constructor(message) {
        super(message);
    }
}

class ProductAlreadyExistsError extends Error {
    constructor(message) {
        super(message);
    }
}



module.exports =
{
    FileReadingError,
    ProductDoNotExists,
    ProductAlreadyExistsError

};

