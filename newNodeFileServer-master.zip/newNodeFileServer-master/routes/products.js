const express = require("express");
const app = express();
const router = express.Router();
const service = require("../service/service");
const Response = require("../models/Response");
const errors = require("../errors/errors");
const ProductAlreadyExistsError = errors.ProductAlreadyExistsError;
const ProductDoNotExists = errors.ProductDoNotExists;



//getallproduct
router.get("/getAllProducts", async (req, res) => {
  try {
    const data = await service.getAllProducts();
    res.status(200).send(
      new Response(
        200,
        "Success",
        "Fetched All Products Successfully",
        data
      ));

  } catch (error) {
    if (error instanceof ProductDoNotExists) {
      res.status(400).send(
        new Response(
          400,
          "Failure",
          error.message,
          null
        ));

    }
    else {
      res.status(500).send(
        new Response(
          500,
          "Failure",
          error.message,
          null
        ));
    }
  }
})

//READ BY PRODUCT ID 
router.get("/:productId", async (req, res) => {
  try {
    const data = await service.getProductByID(req.params.productId);
    res.status(200).send(
      new Response(
        200,
        "Success",
        "Here are the product you requested for",
        data
      ));
  } catch (error) {
    if (error instanceof ProductDoNotExists) {
      res.status(400).send(
        new Response(
          400,
          "Failure",
          "Sorry! This product id do not exists",
          null
        ));
    }
    else {
      res.status(500).send(
        new Response(
          500,
          "Failure",
          error.message,
          null
        ));
    }
  }
})



//create product
router.post("/addProduct", async (req, res) => {
  try {
    const data = await service.addProductData(req.body);
  
    res.status(200).send(
      new Response(
        200,
        "Success",
        "Product added successfully",
        data
      ));
  } catch (error) {
    if (error instanceof ProductAlreadyExistsError) {
      res.status(400).send(
        new Response(
          400,
          "Failure",
          "product already exists",
          null
        ));
    }
    else {
      res.status(500).send(
        new Response(
          500,
          "Failure",
          error.message,
          null
        ));
    }
  }
})

//UPDATE THE PRODUCT 
router.put("/updateProduct", async (req, res) => {
  try {
    const data = await service.updateProductData(req.body);
    res.status(200).send(
      new Response(
        200,
        "Success",
        "Product updated  successfully",
        data
      ));
  } catch (error) {
    if (error instanceof ProductDoNotExists) {
      res.status(400).send(
        new Response(
          400,
          "Failure",
          "Sorry! This product id do not exists",
          null
        ));
    }
    else {
      res.status(500).send(
        new Response(
          500,
          "Failure",
          error.message,
          null
        ));
    }
  }
})

// DELETE PRODUCT BY ID
router.delete("/:productId", async (req, res) => {
  try {
    const data = await service.deleteProductById(req.params.productId);
    res.status(200).send(
      new Response(
        200,
        "Success",
        "Product is deleted",
        data
      ));
  } catch (error) {
    if (error instanceof ProductDoNotExists) {
      res.status(400).send(
        new Response(
          400,
          "Failure",
          "Sorry! This product id do not exists",
          null
        ));
    }
    else {
      res.status(400).send(
        new Response(
          500,
          "Failure",
          error.message,
          null
        ));
    }
  }


});




module.exports = router;
