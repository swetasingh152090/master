const dao = require("../data/dao");
class Service {
    //read all
    async getAllProducts() {
        try {
            return await dao.getAllProducts();
        } catch (error) {
            throw error;

        }
    }

    //read By Id
    async getProductByID(productId) {
        try {
            return await dao.getProductByID(productId);
        } catch (error) {
            throw error;
        }
    }

    //create product
    async addProductData(requestBody) {
        try {
            return await dao.addProductData(requestBody);
        } catch (error) {
            throw error;
        }
    }

    //update prodcut
    async updateProductData(updateBody) {
        try {
            return await dao.updateProductData(updateBody);
        } catch (error) {
            throw error;
        }
    }

    //delete product
    async deleteProductById(productId) {
        try {
            return await dao.deleteProductById(productId);
        } catch (error) {
            throw error;

        }
    }
}



module.exports = new Service();
