const express = require("express");
const app = express();
const cors = require("cors");
app.use(express.json());
app.use(cors());
app.use("/api/products", require("./routes/products"));

const server = app.listen(8081, () => {
  console.log("listening on port %s...", server.address().port);
}
);
module.exports = server;
