const dao = require("../data/dao");
// const productRoute = (app, fs) => {
//     //Json Files
//     const dataPath = "./data/productData.json";

//     //refactor helper methods
//     const readFile = (
//         callback,
//         returnJson = false,
//         filePath = dataPath,
//         encoding = "utf8"
//     ) => {
//         fs.readFile(filePath, encoding, (err, data) => {
//             if (err) {
//                 throw err;
//             }

//             callback(returnJson ? JSON.parse(data) : data);
//         });
//     };

//     const writeFile = (
//         fileData,
//         callback,
//         filePath = dataPath,
//         encoding = "utf8"
//     ) => {
//         fs.writeFile(filePath, fileData, encoding, (err) => {
//             if (err) {
//                 throw err;
//             }

//             callback();
//         });
//     };


class Service {
    async getAllProducts() {
        try {
            return await dao.getAllProducts();
        } catch (error) {
            throw error;

        }
    }

    async getProductByID(productId) {
        try {
            return await dao.getProductByID(productId);
        } catch (error) {
            throw error;
        }
    }

    async addProductData(requestBody) {
        try {
            return await dao.addProductData(requestBody);
        } catch (error) {
            throw error;
        }
    }

    async updateProductData(updateBody) {
        try {
            return await dao.updateProductData(updateBody);
        } catch (error) {
            throw error;
        }
    }

    async deleteProductById(productId) {
        try {
            return await dao.deleteProductById(productId);
        } catch (error) {
            throw error;

        }
    }
}



module.exports = new Service();
