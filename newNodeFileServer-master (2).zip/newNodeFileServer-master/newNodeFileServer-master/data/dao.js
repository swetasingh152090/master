const errors = require("../errors/errors");
var fs = require('fs');
//variable 
let dataPath = "./data/productData.json";
// const { ProductNotExistsError, ProductAlreadyInPlaceError } = require("../errors/errors");
const FileReadingError = errors.FileReadingError;
const ProductWithIdNotExists = errors.ProductWithIdNotExists;
const NoProductExistsError = errors.NoProductExistsError;
const ProductAlreadyInPlaceError = errors.ProductAlreadyInPlaceError;

class Dao {
    //refactor with helper method
    readFile = (callback, returnJson = false, filePath = dataPath, encoding = "utf8") => {
        fs.readFile(filePath, encoding, (err, data) => {
            // console.log("disha jha");
            if (err) {
                throw err;
            }
            callback(returnJson ? JSON.parse(data) : data);
        });
    };
    writeFile = (
        fileData,
        callback,
        filePath = dataPath,
        encoding = "utf8"
    ) => {
        fs.writeFile(filePath, fileData, encoding, (err) => {
            if (err) {
                throw err;
            }

            callback();
        });
    };


    //getall produtc
    async getAllProducts() {
        try {
            let reqData = fs.readFileSync("./data/productData.json");
            let data = JSON.parse(reqData);
            return data;
        } catch (error) {
            if (error.message === "Unexpected end of Json input") {
                throw new NoProductExistsError("the file is empty");
            }
            else {
                throw new FileReadingError("Error reading file");
            }
        }
    }

    //get productid
    async getProductByID(productId) {
        let reqData = fs.readFileSync("./data/productData.json", "utf8");
        console.log("sweta")
        let data = JSON.parse(reqData);
        console.log("deepa");
        let responseData = {};
        let flag;
        for (const element of data) {
            if (productId == element.productId) {
                flag = true;
                console.log("here it is", element);
                responseData = element;
            }
        }
        if (flag) {
            return responseData;
        }
        else {
            throw new ProductWithIdNotExists("No such product exists");
        }
    }

    //create
    async addProductData(requestBody) {

        console.log("DIMPY SINGH")
        let flag = false;
        console.log("vinod singh");
        readFile((data) => {
            console.log("Total Dta", data);
            data.map(eachRecord => {
                if (eachRecord.productId === requestBody.productId) {
                    console.log("singh");
                    flag = true;
                }
            });
            if (!flag) {
                console.log("F;AG:)", flag);
                console.lof("yaha p hai requestbody", requestBody);
                data.push(requestBody);
                console.log("here also data", data);
                writeFile(JSON.stringify(data), () => {

                    console.log("data inserted successfully");
                });

            }

            else {
                console.log("sweta singh");
                throw new ProductAlreadyInPlaceError("Product already exists");
            }
        }, true);
    }

    async updateProductData(updateBody) {
        // let flag;
        readFile((data) => {
            let productId = "";
            data.map(eachRecord => {
                if (eachRecord.productId === updateBody.productId) {
                    // flag = true;
                    productId = eachRecord.productId;
                    eachRecord.productName = updateBody.productName;
                    eachRecord.productCode = updateBody.productCode;
                    eachRecord.releaseDate = updateBody.releaseDate;
                    eachRecord.description = updateBody.description;
                    eachRecord.price = updateBody.price;
                    eachRecord.starRating = updateBody.starRating;
                    eachRecord.imageUrl = updateBody.imageUrl;
                }
            });
            writeFile(JSON.stringify(data), () => {
                // return data;
                //   res.status(200).send(`product id:${productId} updated`);
            });
        }, true);
    }


    //delete data

    async deleteProductById(productId) {
        readFile((data) => {
            let flag;
            // add the new product
            // const productId = req.params["productId"];
            console.log("before======>", data);
            data.map((eachRecord, index) => {
                if (eachRecord.productId === productId) {
                    flag = true;
                    console.log("inside if======>", eachRecord);
                    // data.splice(index, 1);
                }

            });
            if (flag) {
                data.splice(index, 1);
                writeFile(JSON.stringify(data), () => {
                    return data;
                    // res.status(200).send(`product id:${productId} removed`);
                });
            }
            // console.log("after======>", data);
            // writeFile(JSON.stringify(data), () => {
            //     res.status(200).send(`product id:${productId} removed`);
            // });
            else {
                throw new ProductWithIdNotExists("product with the requested id do not exosts");
            }
        }, true);

    }

}
module.exports = new Dao();