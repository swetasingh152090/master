const express = require("express");
const app = express();
const router = express.Router();
const service = require("../service/service");
const Response = require("../models/Response");
const errors = require("../errors/errors");
const NoProductsExistError = errors.NoProductsExistError;
const ProductNotExistsError = errors.ProductNotExistsError;
const ProductWithIdNotExists = errors.ProductWithIdNotExists;
const ProductAlreadyInPlaceError = errors.ProductAlreadyInPlaceError;


//READ
// app.get("/productservice", (req, res) => {
//   fs.readFile(dataPath, "utf8", (err, data) => {
//     if (err) {
//       throw err;
//     }

//     res.send(JSON.parse(data));
//   });
// });

//getallproduct
router.get("/getAllProducts", async (req, res) => {
  try {
    const data = await service.getAllProducts();
    res.status(200).send(
      new Response(
        200,
        "Success",
        "Fetched All Products Successfully",
        data
      ));

  } catch (error) {
    if (error instanceof NoProductsExistError) {
      res.status(400).send(
        new Response(
          400,
          "Failure",
          error.message,
          null
        ));

    }
    else {
      res.status(500).send(
        new Response(
          500,
          "Internal server Error",
          error.message,
          null
        ));
    }
  }
})

//READ BY PRODUCT ID 
router.get("/:productId", async (req, res) => {
  try {
    const data = await service.getProductByID(req.params.productId);
    res.status(200).send(
      new Response(
        200,
        "Success",
        "Here are the product you requested for",
        data
      ));
  } catch (error) {
    if (error instanceof ProductWithIdNotExists) {
      res.status(400).send(
        new Response(
          400,
          "Failure",
          "the product doesn’t exist",
          null
        ));
    }
    else {
      res.status(500).send(
        new Response(
          500,
          "Failure",
          error.message,
          null
        ));
    }
  }
})

// READ by productId
// app.get("/productservice/:productId", (req, res) => {
//   readFile((data) => {
//     const productId = req.params["productId"];
//     let responseData = {};
//     data.map(eachRecord => {
//       if (eachRecord.productId === productId) {
//         responseData = eachRecord;

//       }
//     });
//     res.send({
//       "statusCode": "200",
//       "status": "success",
//       "message": "product data found",
//       "data": responseData

//     })
//     // res.status(200).send(responseData);
//   }, true);
// });

// CREATE
// app.post("/productservice", (req, res) => {
//   readFile((data) => {
//     data.push(req.body);
//     writeFile(JSON.stringify(data), () => {
//       res.status(200).send("new product added");
//     });
//   }, true);
// });

//create product
router.post("/addProduct", async (req, res) => {
  try {
    const data = await service.addProductData(req.body);
    res.status(200).send(
      new Response(
        200,
        "Success",
        "Product added successfully",
        data
      ));
  } catch (error) {
    if (error instanceof ProductAlreadyInPlaceError) {
      res.status(400).send(
        new Response(
          400,
          "Failure",
          "product already exists"
          ,
          null
        ));
    }
    else {
      res.status(500).send(
        new Response(
          500,
          "Failure",
          error.message,
          null
        ));
    }
  }
})

//UPDATE THE PRODUCT 
router.put("/updateProduct",async(req,res)=>
{
  try{
    const data = await service.updateProductData(req.body);
    res.status(200).send(
      new Response(
        200,
        "Success",
        "Product added successfully",
        data
      ));
  }catch(error)
  {
     if(error instanceof ProductWithIdNotExists)
     {
      res.status(400).send(
        new Response(
          400,
          "Failure",
          "Product id do not exists",
          null
        ));
     }
     else{
      res.status(500).send(
        new Response(
          500,
          "Failure",
          error.message,
          null
        ));
     }
  }
})
// // UPDATE
// app.put("/productservice", (req, res) => {
//   readFile((data) => {
//     let productId = "";
//     data.map(eachRecord => {
//       if (eachRecord.productId === req.body.productId) {
//         productId = eachRecord.productId;
//         eachRecord.productName = req.body.productName;
//         eachRecord.productCode = req.body.productCode;
//         eachRecord.releaseDate = req.body.releaseDate;
//         eachRecord.description = req.body.description;
//         eachRecord.price = req.body.price;
//         eachRecord.starRating = req.body.starRating;
//         eachRecord.imageUrl = req.body.imageUrl;
//       }
//     });

//     writeFile(JSON.stringify(data), () => {
//       res.status(200).send(`product id:${productId} updated`);
//     });
//   }, true);
// });

// DELETE PRODUCT BY ID
router.delete("/:productId",async(req,res)=>
{
  try{
    const data = await service.deleteProductById(req.params.productId);
    res.status(200).send(
      new Response(
        200,
        "Success",
        "Product is deleted",
        data
      ));
  }catch(error)
  {
    if(error instanceof ProductWithIdNotExists)
    {
      res.status(400).send(
        new Response(
          400,
          "Failure",
          "Product id do not exists",
          null
        ));
    }
    else{
      res.status(400).send(
        new Response(
          500,
          "Failure",
          error.message,
          null
        ));
    }
  }
 
  
});
// DELETE
//   app.delete("/productservice/:productId", (req, res) => {
//     console.log("delete called", req.params["productId"])
//     readFile((data) => {
//       // add the new product
//       const productId = req.params["productId"];
//       console.log("before======>", data);
//       data.map((eachRecord, index) => {
//         if (eachRecord.productId === productId) {
//           console.log("inside if======>", eachRecord);
//           data.splice(index, 1);
//         }

//       })
//       console.log("after======>", data);
//       writeFile(JSON.stringify(data), () => {
//         res.status(200).send(`product id:${productId} removed`);
//       });
//     }, true);
//   });

// };



module.exports = router;
