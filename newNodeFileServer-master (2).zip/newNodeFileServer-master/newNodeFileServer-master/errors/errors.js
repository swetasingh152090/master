class FileReadingError extends Error
{
    constructor(message)
    {
        super(message);
    }
}

class ProductWithIdNotExists extends Error
{
    constructor(message)
    {
        super(message);
    }
}

class ProductAlreadyInPlaceError extends Error
{
    constructor(message)
    {
        super(message);
    }
}

class NoProductExistsError extends Error
{
    constructor(message)
    {
        super(message);
    }
}

class InvalidProductDataExistsError extends Error
{
    constructor(message)
    {
        
        super(message);
    }
    
}

module.exports=
{
    FileReadingError,
    ProductWithIdNotExists,
    ProductAlreadyInPlaceError,
    NoProductExistsError,
    InvalidProductDataExistsError
};

