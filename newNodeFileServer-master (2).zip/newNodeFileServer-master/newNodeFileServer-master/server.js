// // load up the express framework and body-parser helper
// const express = require("express");
// const bodyParser = require("body-parser");

// // create an instance of express to serve our end points
// const app = express();

// // we'll load up node's built in file system helper library here
// // (we'll be using this later to serve our JSON files
// const fs = require("fs");
// //cors
// const cors=require('cors')
// app.use(cors());
// // configure our express instance with some body-parser settings
// // including handling JSON data
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: false }));

// // this is where we'll handle our various routes from
// const routes = require("./routes/route.js")(app, fs);
// const products = require("./routes/products.js")(app, fs);

// // finally, launch our server on port 8081.
// const server = app.listen(8081, () => {
//   console.log("listening on port %s...", server.address().port);
// });
const express = require("express");
const app = express();
const cors = require("cors");
app.use(express.json());
app.use(cors());
//  const products = require("./routes/products.js");
app.use("/api/products", require("./routes/products"));

const server = app.listen(8081, () => {
  console.log("listening on port %s...", server.address().port);
}
);
